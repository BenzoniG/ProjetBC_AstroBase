var AstroVote_Base = artifacts.require("./AstroVote_Base.sol");

module.exports = function(deployer) {
  deployer.deploy(AstroVote_Base);
};
